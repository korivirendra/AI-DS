from flask import Flask, render_template, request
import csv

app = Flask(__name__)

# Read the CSV file and store data in a list of dictionaries
data = []
with open('recommend.csv', mode='r') as file:
    csv_reader = csv.DictReader(file)
    for row in csv_reader:
        data.append(row)

# Define function to search for service providers by type and location
def search_service_providers(service_type, location):
    results = []
    for row in data:
        if row['service_type'].lower() == service_type.lower() and row['location'].lower() == location.lower():
            results.append(row)
    results = sorted(results, key=lambda x: float(x['avg_rating']), reverse=True)
    return results

# Define Flask routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/', methods=['POST'])
def search():
    service_type = request.form['service_type']
    location = request.form['location']
    results = search_service_providers( service_type, location)
    return render_template('results.html', results=results)

if __name__ == '__main__':
    app.run(debug=True)
